import{_ as e,p as t,q as _}from"./framework-5866ffd3.js";const c={};function r(n,o){return t(),_("div")}const a=e(c,[["render",r],["__file","404.html.vue"]]);export{a as default};
